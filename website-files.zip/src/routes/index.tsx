import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight, Download, Mail, Github, Linkedin, Phone, ExternalLink,
  Code2, Database, Palette, Layers, GraduationCap, Briefcase, Sparkles,
  Menu, X, MapPin, Send,
} from "lucide-react";
import profileAsset from "../assets/profile.jpeg.asset.json";
const profileImg = profileAsset.url;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Janhavi Bansode — Software Engineer & Web Developer" },
      { name: "description", content: "Portfolio of Janhavi Jitendra Bansode — Computer Science and Design Engineer building modern web apps and full-stack solutions." },
    ],
  }),
  component: Portfolio,
});

const NAV = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#education", label: "Education" },
  { href: "#experience", label: "Experience" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#contact", label: "Contact" },
];

function Portfolio() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("animate-fade-up");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    document.querySelectorAll("[data-reveal]").forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-clip">
      {/* NAV */}
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          scrolled ? "glass shadow-elegant" : "bg-transparent"
        }`}
      >
        <nav className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
          <a href="#home" className="font-display font-bold text-lg tracking-tight">
            <span className="text-gradient">Janhavi</span>
            <span className="text-muted-foreground">.dev</span>
          </a>
          <ul className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            {NAV.map((n) => (
              <li key={n.href}>
                <a href={n.href} className="hover:text-foreground transition-colors">
                  {n.label}
                </a>
              </li>
            ))}
          </ul>
          <a
            href="#contact"
            className="hidden md:inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:shadow-glow transition-all"
          >
            Let's talk <ArrowRight className="size-4" />
          </a>
          <button
            className="md:hidden rounded-md p-2 text-foreground"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </nav>
        {open && (
          <div className="md:hidden glass border-t border-border">
            <ul className="px-6 py-4 space-y-3">
              {NAV.map((n) => (
                <li key={n.href}>
                  <a
                    href={n.href}
                    onClick={() => setOpen(false)}
                    className="block py-1 text-muted-foreground hover:text-foreground"
                  >
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        )}
      </header>

      {/* HERO */}
      <section id="home" className="relative pt-32 pb-24 bg-hero-gradient">
        <div className="pointer-events-none absolute inset-0 overflow-hidden">
          <div className="absolute -top-20 -left-20 size-96 rounded-full bg-primary/20 blur-3xl animate-blob" />
          <div className="absolute top-40 -right-20 size-96 rounded-full bg-accent/20 blur-3xl animate-blob [animation-delay:-6s]" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6 grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
          <div className="animate-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs text-muted-foreground">
              <span className="size-2 rounded-full bg-emerald-400 animate-pulse" />
              Available for opportunities
            </span>
            <h1 className="mt-6 text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.05]">
              Hi, I'm <span className="text-gradient">Janhavi Bansode</span>
              <br />
              I build modern digital experiences.
            </h1>
            <p className="mt-4 text-base sm:text-lg text-muted-foreground max-w-xl">
              Computer Science & Design Engineer · Software Engineer · Web Developer.
              Passionate about clean code, intuitive interfaces, and full-stack craft.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#projects"
                className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-medium text-primary-foreground shadow-elegant hover:shadow-glow transition-all"
              >
                View Projects <ArrowRight className="size-4" />
              </a>
              <a
                href="/resume.pdf"
                className="inline-flex items-center gap-2 rounded-full glass px-5 py-3 text-sm font-medium hover:bg-card transition-all"
              >
                <Download className="size-4" /> Download Resume
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 rounded-full border border-border px-5 py-3 text-sm font-medium hover:bg-card transition-all"
              >
                <Mail className="size-4" /> Contact Me
              </a>
            </div>
            <div className="mt-8 flex items-center gap-4 text-muted-foreground">
              <a href="https://www.linkedin.com/in/janhavi-bansode-249627414" target="_blank" rel="noreferrer" className="hover:text-foreground transition-colors"><Linkedin className="size-5" /></a>
              <a href="mailto:bansodejanhavi05@gmail.com" className="hover:text-foreground transition-colors"><Mail className="size-5" /></a>
              <a href="#" className="hover:text-foreground transition-colors"><Github className="size-5" /></a>
            </div>
          </div>
          <div className="relative animate-fade-up [animation-delay:200ms]">
            <div className="relative mx-auto w-72 sm:w-80 lg:w-full max-w-md aspect-square">
              <div className="absolute inset-0 rounded-[2rem] bg-gradient-to-br from-primary to-accent blur-2xl opacity-40 animate-float" />
              <div className="relative rounded-[2rem] overflow-hidden glass shadow-elegant animate-float">
                <img
                  src={profileImg}
                  alt="Janhavi Jitendra Bansode portrait"
                  width={768}
                  height={768}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 glass rounded-2xl px-4 py-3 shadow-elegant">
                <p className="text-xs text-muted-foreground">CGPA</p>
                <p className="text-lg font-bold text-gradient">7.01 / 10</p>
              </div>
              <div className="absolute -top-4 -right-4 glass rounded-2xl px-4 py-3 shadow-elegant">
                <p className="text-xs text-muted-foreground">Class of</p>
                <p className="text-lg font-bold">2026</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <Section id="about" eyebrow="About" title="A bit about me">
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 glass rounded-2xl p-8" data-reveal>
            <p className="text-base sm:text-lg leading-relaxed text-muted-foreground">
              I'm a Computer Science and Design Engineering graduate with a passion for
              software development and web technologies. I've built projects spanning
              web applications, games, and health-tracking tools, while sharpening my
              craft through internships and certifications.
            </p>
            <p className="mt-4 text-base sm:text-lg leading-relaxed text-muted-foreground">
              My goal is to build innovative software solutions and grow as a
              Software Engineer and Full-Stack Developer — shipping work that's
              fast, accessible, and delightful to use.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4" data-reveal>
            <Stat label="Projects" value="3+" />
            <Stat label="Internships" value="1" />
            <Stat label="Certifications" value="2" />
            <Stat label="CGPA" value="7.01" />
          </div>
        </div>
      </Section>

      {/* EDUCATION */}
      <Section id="education" eyebrow="Education" title="Academic background">
        <div className="glass rounded-2xl p-8 max-w-3xl" data-reveal>
          <div className="flex gap-5">
            <div className="shrink-0 size-12 rounded-xl bg-primary/15 grid place-items-center text-primary">
              <GraduationCap className="size-6" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-xl font-semibold">Bachelor of Engineering (B.E.)</h3>
                <span className="text-xs rounded-full bg-primary/15 text-primary px-2 py-0.5">2026</span>
              </div>
              <p className="mt-1 text-muted-foreground">Computer Science and Design Engineering</p>
              <p className="mt-2 text-sm text-muted-foreground">
                New Horizon Institute of Technology & Management
              </p>
              <p className="mt-3 text-sm">CGPA: <span className="text-gradient font-semibold">7.01 / 10</span></p>
            </div>
          </div>
        </div>
      </Section>

      {/* EXPERIENCE */}
      <Section id="experience" eyebrow="Experience" title="Training & internships">
        <div className="relative max-w-4xl">
          <div className="absolute left-4 sm:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-primary/60 via-border to-transparent" />
          {EXPERIENCE.map((e, i) => (
            <div key={e.title} className="relative pl-12 sm:pl-0 sm:grid sm:grid-cols-2 sm:gap-12 mb-10" data-reveal>
              <div className={i % 2 === 0 ? "sm:text-right sm:pr-10" : "sm:col-start-2 sm:pl-10"}>
                <div className="absolute left-2 sm:left-1/2 -translate-x-1/2 mt-2 size-4 rounded-full bg-primary shadow-glow" />
                <div className="glass rounded-2xl p-6 hover:shadow-glow transition-shadow">
                  <div className="flex items-center gap-2 justify-start sm:justify-inherit">
                    <Briefcase className="size-4 text-primary" />
                    <span className="text-xs text-muted-foreground">{e.year}</span>
                  </div>
                  <h3 className="mt-2 text-lg font-semibold">{e.title}</h3>
                  <p className="text-sm text-primary">{e.org}</p>
                  <p className="mt-2 text-sm text-muted-foreground">{e.desc}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* SKILLS */}
      <Section id="skills" eyebrow="Skills" title="What I work with">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SKILL_GROUPS.map((g) => (
            <div key={g.title} className="glass rounded-2xl p-6 hover:shadow-elegant transition-shadow" data-reveal>
              <div className="flex items-center gap-3 mb-5">
                <div className="size-10 rounded-lg bg-primary/15 text-primary grid place-items-center">
                  <g.icon className="size-5" />
                </div>
                <h3 className="font-semibold">{g.title}</h3>
              </div>
              <div className="space-y-3">
                {g.skills.map((s) => (
                  <div key={s.name}>
                    <div className="flex justify-between text-sm mb-1">
                      <span>{s.name}</span>
                      <span className="text-muted-foreground">{s.level}%</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-primary to-accent origin-left"
                        style={{ width: `${s.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap gap-2" data-reveal>
          {["Web Development", "Full-Stack Development", "UI/UX Design", "Responsive Design", "Problem Solving"].map((t) => (
            <span key={t} className="rounded-full glass px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
              {t}
            </span>
          ))}
        </div>
      </Section>

      {/* SERVICES */}
      <Section id="services" eyebrow="Services" title="What I can do for you">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {SERVICES.map((s) => (
            <div key={s.title} className="group glass rounded-2xl p-6 hover:-translate-y-1 hover:shadow-glow transition-all" data-reveal>
              <div className="size-11 rounded-xl bg-gradient-to-br from-primary to-accent grid place-items-center text-primary-foreground mb-4 group-hover:scale-110 transition-transform">
                <s.icon className="size-5" />
              </div>
              <h3 className="font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* PROJECTS */}
      <Section id="projects" eyebrow="Projects" title="Selected work">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PROJECTS.map((p, i) => (
            <article
              key={p.title}
              className="group glass rounded-2xl overflow-hidden hover:shadow-glow hover:-translate-y-1 transition-all flex flex-col"
              data-reveal
            >
              <div className={`relative aspect-[16/10] overflow-hidden bg-gradient-to-br ${p.gradient}`}>
                <div className="absolute inset-0 grid place-items-center text-primary-foreground/90">
                  <p.icon className="size-16 opacity-80 group-hover:scale-110 transition-transform" />
                </div>
                <div className="absolute top-3 left-3 rounded-full glass px-2.5 py-1 text-[10px] uppercase tracking-wider text-muted-foreground">
                  #{String(i + 1).padStart(2, "0")}
                </div>
              </div>
              <div className="p-6 flex-1 flex flex-col">
                <h3 className="text-lg font-semibold">{p.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground flex-1">{p.desc}</p>
                <div className="mt-4 flex flex-wrap gap-1.5">
                  {p.tech.map((t) => (
                    <span key={t} className="text-[11px] rounded-md bg-primary/10 text-primary px-2 py-0.5">{t}</span>
                  ))}
                </div>
                <ul className="mt-4 space-y-1 text-xs text-muted-foreground">
                  {p.features.map((f) => (
                    <li key={f} className="flex gap-2"><span className="text-primary">▸</span>{f}</li>
                  ))}
                </ul>
                <div className="mt-5 flex gap-2">
                  <a href="#" className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg bg-primary px-3 py-2 text-xs font-medium text-primary-foreground hover:shadow-glow transition-all">
                    <ExternalLink className="size-3.5" /> Live Demo
                  </a>
                  <a href="#" className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg border border-border px-3 py-2 text-xs font-medium hover:bg-card transition-all">
                    <Github className="size-3.5" /> GitHub
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </Section>

      {/* CONTACT */}
      <Section id="contact" eyebrow="Contact" title="Let's build something together">
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="space-y-4" data-reveal>
            <ContactCard icon={Mail} label="Email" value="bansodejanhavi05@gmail.com" href="mailto:bansodejanhavi05@gmail.com" />
            <ContactCard icon={Phone} label="Phone" value="+91 70395 80252" href="tel:+917039580252" />
            <ContactCard icon={Linkedin} label="LinkedIn" value="janhavi-bansode-249627414" href="https://www.linkedin.com/in/janhavi-bansode-249627414" />
            <ContactCard icon={MapPin} label="Based in" value="India · Open to remote" />
          </div>
          <form
            className="glass rounded-2xl p-6 space-y-4"
            data-reveal
            onSubmit={(e) => {
              e.preventDefault();
              const data = new FormData(e.currentTarget);
              const subject = encodeURIComponent(`Portfolio inquiry from ${data.get("name")}`);
              const body = encodeURIComponent(`${data.get("message")}\n\n— ${data.get("name")} (${data.get("email")})`);
              window.location.href = `mailto:bansodejanhavi05@gmail.com?subject=${subject}&body=${body}`;
            }}
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <Field name="name" label="Your name" placeholder="Jane Doe" required />
              <Field name="email" type="email" label="Email" placeholder="jane@company.com" required />
            </div>
            <Field name="subject" label="Subject" placeholder="Project opportunity" />
            <div>
              <label className="text-xs text-muted-foreground">Message</label>
              <textarea
                name="message"
                required
                rows={5}
                placeholder="Tell me about your project..."
                className="mt-1 w-full rounded-lg bg-input/40 border border-border px-3 py-2 text-sm outline-none focus:border-primary transition-colors"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-medium text-primary-foreground shadow-elegant hover:shadow-glow transition-all"
            >
              <Send className="size-4" /> Send Message
            </button>
          </form>
        </div>
      </Section>

      {/* FOOTER */}
      <footer className="border-t border-border mt-10">
        <div className="mx-auto max-w-7xl px-6 py-10 grid md:grid-cols-3 gap-6 items-start">
          <div>
            <p className="font-display font-bold text-lg"><span className="text-gradient">Janhavi Bansode</span></p>
            <p className="text-sm text-muted-foreground mt-1">Software Engineer · Web Developer</p>
          </div>
          <ul className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground md:justify-center">
            {NAV.map((n) => (
              <li key={n.href}><a href={n.href} className="hover:text-foreground">{n.label}</a></li>
            ))}
          </ul>
          <div className="flex md:justify-end gap-3 text-muted-foreground">
            <a href="https://www.linkedin.com/in/janhavi-bansode-249627414" target="_blank" rel="noreferrer" className="hover:text-foreground"><Linkedin className="size-5" /></a>
            <a href="mailto:bansodejanhavi05@gmail.com" className="hover:text-foreground"><Mail className="size-5" /></a>
            <a href="#" className="hover:text-foreground"><Github className="size-5" /></a>
          </div>
        </div>
        <div className="border-t border-border">
          <p className="mx-auto max-w-7xl px-6 py-5 text-xs text-muted-foreground text-center">
            © 2026 Janhavi Jitendra Bansode. All Rights Reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}

function Section({
  id, eyebrow, title, children,
}: { id: string; eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <section id={id} className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-6">
        <div className="mb-12 max-w-2xl" data-reveal>
          <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-primary">
            <Sparkles className="size-3.5" /> {eyebrow}
          </span>
          <h2 className="mt-3 text-3xl sm:text-4xl font-bold">{title}</h2>
        </div>
        {children}
      </div>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-2xl p-5">
      <p className="text-2xl font-bold text-gradient">{value}</p>
      <p className="text-xs text-muted-foreground mt-1">{label}</p>
    </div>
  );
}

function ContactCard({
  icon: Icon, label, value, href,
}: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; href?: string }) {
  const inner = (
    <div className="glass rounded-2xl p-5 flex items-center gap-4 hover:shadow-glow transition-all">
      <div className="size-11 rounded-xl bg-primary/15 text-primary grid place-items-center shrink-0">
        <Icon className="size-5" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="truncate text-sm font-medium">{value}</p>
      </div>
    </div>
  );
  return href ? <a href={href} target={href.startsWith("http") ? "_blank" : undefined} rel="noreferrer">{inner}</a> : inner;
}

function Field({
  name, label, type = "text", placeholder, required,
}: { name: string; label: string; type?: string; placeholder?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-xs text-muted-foreground">{label}</label>
      <input
        type={type}
        name={name}
        required={required}
        placeholder={placeholder}
        className="mt-1 w-full rounded-lg bg-input/40 border border-border px-3 py-2 text-sm outline-none focus:border-primary transition-colors"
      />
    </div>
  );
}

const EXPERIENCE = [
  { title: "Python Internship", org: "Ignitech", year: "2022", desc: "Training focused on Python programming fundamentals and practical development concepts." },
  { title: "Frontend Development Program", org: "Udemy", year: "2023", desc: "Learned HTML, CSS, JavaScript, and modern frontend web development practices." },
  { title: "Advanced Course on Green Skills & AI", org: "Edunet", year: "2026", desc: "Specialized training on Artificial Intelligence, sustainability, and emerging technologies." },
];

const SKILL_GROUPS = [
  { title: "Frontend", icon: Code2, skills: [
    { name: "HTML", level: 90 }, { name: "CSS", level: 85 }, { name: "JavaScript", level: 80 }, { name: "React", level: 60 },
  ]},
  { title: "Backend", icon: Layers, skills: [
    { name: "Python", level: 85 },
  ]},
  { title: "Database", icon: Database, skills: [
    { name: "MySQL", level: 80 },
  ]},
];

const SERVICES = [
  { title: "Web Development", desc: "Responsive, user-friendly websites built with modern technologies.", icon: Code2 },
  { title: "Frontend Development", desc: "Interactive, visually appealing interfaces with attention to detail.", icon: Layers },
  { title: "Full-Stack Development", desc: "Complete web apps from frontend to backend, end to end.", icon: Database },
  { title: "UI/UX Design", desc: "Intuitive experiences and engaging visual interfaces.", icon: Palette },
];

const PROJECTS = [
  {
    title: "Art Gallery Website",
    desc: "A web platform to browse and view artwork stored in a database through a clean, user-friendly interface.",
    tech: ["HTML", "CSS", "PHP", "MySQL"],
    features: ["Artwork database integration", "Responsive design", "Dynamic content management"],
    icon: Palette,
    gradient: "from-violet-500/30 via-fuchsia-500/20 to-pink-500/20",
  },
  {
    title: "Mummy Island Game",
    desc: "An adventure game on a deserted island — eliminate mummies, overcome challenges and progress through levels.",
    tech: ["Python", "HTML", "CSS"],
    features: ["Multiple game levels", "Interactive gameplay", "Character progression"],
    icon: Sparkles,
    gradient: "from-amber-500/30 via-orange-500/20 to-rose-500/20",
  },
  {
    title: "SmartBite — Calorie Tracker",
    desc: "A calorie tracking web app helping users monitor daily food intake and nutritional information.",
    tech: ["Python", "React", "JavaScript"],
    features: ["Food intake tracking", "Nutrition monitoring", "React frontend · Python backend"],
    icon: Layers,
    gradient: "from-emerald-500/30 via-teal-500/20 to-cyan-500/20",
  },
];
